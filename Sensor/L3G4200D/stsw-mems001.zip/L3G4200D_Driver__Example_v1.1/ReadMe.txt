
In the folder *_driver there are the driver files of Mems Sensor (.h and .c) to be included in your project.
The driver is platform independent, you need only complete the two functions for write and read from Mems Hardware Bus.

The example_main.c file, is an example for how to use the Mems driver in a project.
It is written for STEVAL-MKI109V1 Evaluation Board, but you can use it as a guideline for all board.

www.st.com/mems